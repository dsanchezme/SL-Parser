#!/usr/bin/python

import lexer_parser

token = ''
nextToken = ''

def init():
	global token
	global nextToken
	nextToken = lexer_parser.getNextToken()
	token = nextToken[0]
	codigo()
	if(token != '$'):
		syntaxError(set({'$'}))
	print('El analisis sintactico ha finalizado exitosamente.')

def syntaxError(posibles):
	lexema = nextToken[1]
	row = nextToken[2]
	col = nextToken[3]
	posibleList = []
	for posible in posibles:
		if posible in lexer_parser.operators1.values():
			match = list(lexer_parser.operators1.keys())[list(lexer_parser.operators1.values()).index(posible)]
		elif posible in lexer_parser.operators2.values():
			match = list(lexer_parser.operators2.keys())[list(lexer_parser.operators2.values()).index(posible)]
		elif posible == 'id':
			match = 'identificador'
		else:
			match = posible
		posibleList.append("'"+match+"'")
	if(lexema == '$'):
		print(f"<{row}:{col}> Error sintactico: se encontro final de archivo; se esperaba: {', '.join(sorted(posibleList))}.")
	else:
		print(f"<{row}:{col}> Error sintactico: se encontro: '{lexema}'; se esperaba: {', '.join(sorted(posibleList))}.")
	quit()

def emparejar(esperado):
	global token
	global nextToken
	if(token == esperado):
		nextToken = lexer_parser.getNextToken()
		token = nextToken[0]
	else:
		syntaxError(set({esperado}))

def codigo():
	if(token == 'inicio' or token == 'var' or token == 'tipos' or token == 'programa' or token == 'const'):
		nombre()
		declaracion()
		main()
		subrutina_()
	else:
		syntaxError(set({'inicio', 'var', 'tipos', 'programa', 'const'}))


def nombre():
	if(token == 'programa'):
		emparejar('programa')
		emparejar('id')
	elif(token == 'inicio' or token == 'var' or token == 'tipos' or token == 'const'):
		pass
	else:
		syntaxError(set({'inicio', 'var', 'const', 'programa', 'tipos'}))


def declaracion():
	if(token == 'var'):
		emparejar('var')
		declaracion_contenido_var()
		declaracion()
	elif(token == 'tipos'):
		emparejar('tipos')
		declaracion_contenido_tipos()
		declaracion()
	elif(token == 'const'):
		emparejar('const')
		declaracion_contenido_const()
		declaracion()
	elif(token == 'inicio'):
		pass
	else:
		syntaxError(set({'inicio', 'var', 'const', 'tipos'}))


def declaracion_contenido_const():
	if(token == 'id'):
		emparejar('id')
		emparejar('tk_asignacion')
		expresion()
		mas_declaraciones_const()
	else:
		syntaxError(set({'id'}))


def declaracion_contenido_tipos():
	if(token == 'id'):
		emparejar('id')
		emparejar('tk_dos_puntos')
		tipo_dato()
		mas_declaraciones_tipos()
	else:
		syntaxError(set({'id'}))


def declaracion_contenido_var():
	if(token == 'id'):
		emparejar('id')
		otros_id()
		emparejar('tk_dos_puntos')
		tipo_dato()
		mas_declaraciones_var()
	else:
		syntaxError(set({'id'}))


def valor():
	if(token == 'id'):
		emparejar('id')
		valor_aux()
	elif(token == 'TRUE' or token == 'tk_suma' or token == 'tk_cadena' or token == 'SI' or token == 'tk_resta' or token == 'NO' or token == 'tk_numero' or token == 'FALSE'):
		variable()
	else:
		syntaxError(set({'id', 'TRUE', 'tk_suma', 'tk_cadena', 'FALSE', 'tk_resta', 'NO', 'tk_numero', 'SI'}))


def valor_aux():
	if(token == 'tk_parentesis_izquierdo'):
		llamada_subrutina()
	elif(token == 'tk_corchete_izquierdo' or token == 'tk_punto'):
		id_arreglo_registro()
	elif(token == 'id' or token == 'tk_potenciacion' or token == 'tk_suma' or token == 'retorna' or token == 'tk_division' or token == 'tk_multiplicacion' or token == 'tipos' or token == 'tk_modulo' or token == 'desde' or token == 'const' or token == 'mientras' or token == 'tk_corchete_derecho' or token == 'hasta' or token == 'tk_mayor' or token == 'tk_coma' or token == 'var' or token == 'sino' or token == 'tk_mayor_igual' or token == 'tk_resta' or token == 'paso' or token == 'tk_menor' or token == 'repetir' or token == 'tk_parentesis_derecho' or token == 'tk_llave_derecha' or token == 'caso' or token == 'inicio' or token == 'tk_llave_izquierda' or token == 'tk_punto_y_coma' or token == 'fin' or token == 'and' or token == 'or' or token == 'tk_menor_igual' or token == 'eval' or token == 'si' or token == 'tk_igual_que' or token == 'tk_distinto_de'):
		pass
	else:
		syntaxError(set({'id', 'tk_potenciacion', 'tk_suma', 'retorna', 'tk_division', 'tk_multiplicacion', 'tipos', 'tk_igual_que', 'tk_corchete_izquierdo', 'tk_modulo', 'desde', 'tk_punto', 'const', 'mientras', 'tk_corchete_derecho', 'hasta', 'tk_parentesis_izquierdo', 'tk_mayor', 'tk_coma', 'var', 'sino', 'tk_mayor_igual', 'tk_resta', 'paso', 'tk_menor', 'repetir', 'tk_parentesis_derecho', 'caso', 'inicio', 'tk_llave_izquierda', 'tk_punto_y_coma', 'fin', 'and', 'or', 'tk_menor_igual', 'eval', 'si', 'tk_llave_derecha', 'tk_distinto_de'}))


def variable():
	if(token == 'tk_numero'):
		emparejar('tk_numero')
	elif(token == 'tk_cadena'):
		emparejar('tk_cadena')
	elif(token == 'TRUE'):
		emparejar('TRUE')
	elif(token == 'FALSE'):
		emparejar('FALSE')
	elif(token == 'SI'):
		emparejar('SI')
	elif(token == 'NO'):
		emparejar('NO')
	elif(token == 'tk_suma' or token == 'tk_resta'):
		signo()
		variable_aux()
	else:
		syntaxError(set({'NO', 'TRUE', 'tk_suma', 'tk_numero', 'tk_cadena', 'SI', 'FALSE', 'tk_resta'}))


def variable_aux():
	if(token == 'id'):
		emparejar('id')
	elif(token == 'tk_numero'):
		emparejar('tk_numero')
	else:
		syntaxError(set({'id', 'tk_numero'}))


def signo():
	if(token == 'tk_suma'):
		emparejar('tk_suma')
	elif(token == 'tk_resta'):
		emparejar('tk_resta')
	else:
		syntaxError(set({'tk_suma', 'tk_resta'}))


def otros_id():
	if(token == 'tk_coma'):
		emparejar('tk_coma')
		emparejar('id')
		otros_id()
	elif(token == 'tk_dos_puntos'):
		pass
	else:
		syntaxError(set({'tk_dos_puntos', 'tk_coma'}))


def tipo_dato():
	if(token == 'id'):
		emparejar('id')
	elif(token == 'cadena'):
		emparejar('cadena')
	elif(token == 'logico'):
		emparejar('logico')
	elif(token == 'numerico'):
		emparejar('numerico')
	elif(token == 'registro'):
		emparejar('registro')
		emparejar('tk_llave_izquierda')
		declaracion_contenido_var()
		emparejar('tk_llave_derecha')
	elif(token == 'vector'):
		emparejar('vector')
		emparejar('tk_corchete_izquierdo')
		tamano_arreglo()
		emparejar('tk_corchete_derecho')
		tipo_dato()
	elif(token == 'matriz'):
		emparejar('matriz')
		emparejar('tk_corchete_izquierdo')
		tamano_arreglo()
		mas_tamano_arreglo()
		emparejar('tk_corchete_derecho')
		tipo_dato()
	else:
		syntaxError(set({'id', 'logico', 'registro', 'cadena', 'vector', 'matriz', 'numerico'}))


def tamano_arreglo():
	if(token == 'tk_numero'):
		emparejar('tk_numero')
	elif(token == 'tk_multiplicacion'):
		emparejar('tk_multiplicacion')
	elif(token == 'id'):
		emparejar('id')
	else:
		syntaxError(set({'id', 'tk_numero', 'tk_multiplicacion'}))


def mas_tamano_arreglo():
	if(token == 'tk_coma'):
		emparejar('tk_coma')
		tamano_arreglo()
		mas_tamano_arreglo()
	elif(token == 'tk_corchete_derecho'):
		pass
	else:
		syntaxError(set({'tk_corchete_derecho', 'tk_coma'}))


def mas_declaraciones_var():
	if(token == 'tk_punto_y_coma' or token == 'id'):
		punto_y_coma_opcional()
		declaracion_contenido_var()
	elif(token == 'inicio' or token == 'var' or token == 'const' or token == 'tipos' or token == 'tk_llave_derecha'):
		pass
	else:
		syntaxError(set({'id', 'inicio', 'var', 'tipos', 'const', 'tk_punto_y_coma', 'tk_llave_derecha'}))


def mas_declaraciones_tipos():
	if(token == 'tk_punto_y_coma' or token == 'id'):
		punto_y_coma_opcional()
		declaracion_contenido_tipos()
	elif(token == 'inicio' or token == 'var' or token == 'tipos' or token == 'const'):
		pass
	else:
		syntaxError(set({'id', 'inicio', 'var', 'const', 'tipos', 'tk_punto_y_coma'}))


def mas_declaraciones_const():
	if(token == 'tk_punto_y_coma' or token == 'id'):
		punto_y_coma_opcional()
		declaracion_contenido_const()
	elif(token == 'inicio' or token == 'var' or token == 'tipos' or token == 'const'):
		pass
	else:
		syntaxError(set({'id', 'inicio', 'var', 'const', 'tipos', 'tk_punto_y_coma'}))


def main():
	if(token == 'inicio'):
		emparejar('inicio')
		sentencias()
		emparejar('fin')
	else:
		syntaxError(set({'inicio'}))


def sentencias():
	if(token == 'id' or token == 'repetir' or token == 'desde' or token == 'eval' or token == 'si' or token == 'mientras'):
		sentencia()
		sentencias_aux()
	elif(token == 'fin'):
		pass
	else:
		syntaxError(set({'id', 'repetir', 'eval', 'si', 'fin', 'mientras', 'desde'}))


def sentencias_aux():
	if(token == 'id' or token == 'repetir' or token == 'eval' or token == 'si' or token == 'tk_punto_y_coma' or token == 'fin' or token == 'mientras' or token == 'desde'):
		punto_y_coma_opcional()
		sentencias()
	elif(token == 'retorna' or token == 'fin'):
		sentencia_retorna_main()
	else:
		syntaxError(set({'id', 'repetir', 'retorna', 'desde', 'eval', 'si', 'tk_punto_y_coma', 'mientras', 'fin'}))


def sentencia():
	if(token == 'id'):
		emparejar('id')
		id_casos()
	elif(token == 'si'):
		condicional()
	elif(token == 'mientras'):
		ciclo_mientras()
	elif(token == 'eval'):
		sentencia_eval()
	elif(token == 'desde'):
		ciclo_desde()
	elif(token == 'repetir'):
		ciclo_repetir()
	else:
		syntaxError(set({'id', 'repetir', 'eval', 'si', 'mientras', 'desde'}))


def sentencias_internas():
	if(token == 'id' or token == 'repetir' or token == 'desde' or token == 'eval' or token == 'si' or token == 'mientras'):
		sentencia_interna()
		punto_y_coma_opcional()
		sentencias_internas()
	elif(token == 'tk_llave_derecha' or token == 'hasta' or token == 'sino' or token == 'caso'):
		pass
	else:
		syntaxError(set({'id', 'repetir', 'hasta', 'desde', 'caso', 'eval', 'sino', 'si', 'tk_llave_derecha', 'mientras'}))


def sentencia_interna():
	if(token == 'id'):
		emparejar('id')
		id_casos()
	elif(token == 'si'):
		condicional()
	elif(token == 'mientras'):
		ciclo_mientras()
	elif(token == 'eval'):
		sentencia_eval()
	elif(token == 'desde'):
		ciclo_desde()
	elif(token == 'repetir'):
		ciclo_repetir()
	else:
		syntaxError(set({'id', 'repetir', 'eval', 'si', 'mientras', 'desde'}))


def id_casos():
	if(token == 'tk_asignacion'):
		asignacion()
	elif(token == 'tk_parentesis_izquierdo'):
		llamada_subrutina()
	elif(token == 'tk_corchete_izquierdo' or token == 'tk_punto'):
		id_arreglo_registro()
		asignacion()
	else:
		syntaxError(set({'tk_parentesis_izquierdo', 'tk_corchete_izquierdo', 'tk_punto', 'tk_asignacion'}))


def punto_y_coma_opcional():
	if(token == 'tk_punto_y_coma'):
		emparejar('tk_punto_y_coma')
	elif(token == 'id' or token == 'repetir' or token == 'hasta' or token == 'desde' or token == 'caso' or token == 'eval' or token == 'sino' or token == 'si' or token == 'tk_llave_derecha' or token == 'mientras' or token == 'fin'):
		pass
	else:
		syntaxError(set({'id', 'repetir', 'hasta', 'desde', 'caso', 'eval', 'sino', 'si', 'tk_punto_y_coma', 'tk_llave_derecha', 'mientras', 'fin'}))


def expresion():
	if(token == 'TRUE' or token == 'tk_suma' or token == 'tk_cadena' or token == 'SI' or token == 'tk_resta' or token == 'NO' or token == 'tk_numero' or token == 'FALSE'):
		variable()
		expresion_aux()
	elif(token == 'tk_parentesis_izquierdo'):
		emparejar('tk_parentesis_izquierdo')
		expresion()
		emparejar('tk_parentesis_derecho')
		expresion_aux()
	elif(token == 'not'):
		emparejar('not')
		expresion()
		expresion_aux()
	elif(token == 'id'):
		emparejar('id')
		valor_aux()
		expresion_aux()
	elif(token == 'tk_llave_izquierda'):
		valores_vector()
		expresion_aux()
	else:
		syntaxError(set({'id', 'TRUE', 'tk_suma', 'tk_cadena', 'SI', 'tk_parentesis_izquierdo', 'not', 'tk_resta', 'tk_llave_izquierda', 'NO', 'tk_numero', 'FALSE'}))


def expresion_aux():
	if(token == 'tk_menor' or token == 'tk_potenciacion' or token == 'tk_suma' or token == 'tk_division' or token == 'tk_multiplicacion' or token == 'and' or token == 'or' or token == 'tk_mayor' or token == 'tk_modulo' or token == 'tk_distinto_de' or token == 'tk_menor_igual' or token == 'tk_mayor_igual' or token == 'tk_igual_que' or token == 'tk_resta'):
		operador()
		expresion()
	elif(token == 'id' or token == 'tk_potenciacion' or token == 'tk_suma' or token == 'retorna' or token == 'tk_division' or token == 'tipos' or token == 'tk_multiplicacion' or token == 'tk_modulo' or token == 'desde' or token == 'const' or token == 'mientras' or token == 'tk_corchete_derecho' or token == 'hasta' or token == 'tk_mayor' or token == 'tk_coma' or token == 'var' or token == 'sino' or token == 'tk_mayor_igual' or token == 'tk_resta' or token == 'paso' or token == 'tk_menor' or token == 'repetir' or token == 'tk_parentesis_derecho' or token == 'tk_llave_derecha' or token == 'caso' or token == 'inicio' or token == 'tk_llave_izquierda' or token == 'tk_punto_y_coma' or token == 'fin' or token == 'and' or token == 'or' or token == 'tk_menor_igual' or token == 'eval' or token == 'si' or token == 'tk_igual_que' or token == 'tk_distinto_de'):
		pass
	else:
		syntaxError(set({'id', 'tk_potenciacion', 'tk_suma', 'retorna', 'tk_division', 'tk_multiplicacion', 'tipos', 'tk_modulo', 'desde', 'const', 'mientras', 'tk_corchete_derecho', 'hasta', 'tk_mayor', 'tk_coma', 'var', 'sino', 'tk_mayor_igual', 'tk_resta', 'paso', 'tk_menor', 'repetir', 'tk_parentesis_derecho', 'tk_llave_derecha', 'caso', 'inicio', 'tk_llave_izquierda', 'tk_punto_y_coma', 'fin', 'and', 'or', 'tk_menor_igual', 'eval', 'si', 'tk_igual_que', 'tk_distinto_de'}))


def valores_vector():
	if(token == 'tk_llave_izquierda'):
		emparejar('tk_llave_izquierda')
		posibles_valores_vector()
		mas_valores_vector()
		emparejar('tk_llave_derecha')
	else:
		syntaxError(set({'tk_llave_izquierda'}))


def posibles_valores_vector():
	if(token == 'id' or token == 'TRUE' or token == 'tk_suma' or token == 'tk_cadena' or token == 'FALSE' or token == 'tk_resta' or token == 'NO' or token == 'tk_numero' or token == 'SI'):
		valor()
	elif(token == 'tk_llave_izquierda'):
		valores_vector()
	elif(token == 'tk_llave_derecha' or token == 'tk_coma'):
		pass
	else:
		syntaxError(set({'id', 'TRUE', 'tk_suma', 'tk_cadena', 'FALSE', 'tk_resta', 'tk_coma', 'tk_llave_izquierda', 'NO', 'tk_numero', 'tk_llave_derecha', 'SI'}))


def mas_valores_vector():
	if(token == 'tk_coma'):
		emparejar('tk_coma')
		posibles_valores_vector()
		mas_valores_vector()
	elif(token == 'tk_llave_derecha'):
		pass
	else:
		syntaxError(set({'tk_llave_derecha', 'tk_coma'}))


def id_arreglo_registro():
	if(token == 'tk_corchete_izquierdo'):
		emparejar('tk_corchete_izquierdo')
		expresion()
		mas_parametros()
		emparejar('tk_corchete_derecho')
		mas_pos_valor()
	elif(token == 'tk_punto'):
		emparejar('tk_punto')
		emparejar('id')
		mas_pos_valor()
	else:
		syntaxError(set({'tk_corchete_izquierdo', 'tk_punto'}))


def mas_pos_valor():
	if(token == 'tk_corchete_izquierdo' or token == 'tk_punto'):
		id_arreglo_registro()
	elif(token == 'id' or token == 'tk_potenciacion' or token == 'tk_suma' or token == 'retorna' or token == 'tk_division' or token == 'tk_multiplicacion' or token == 'tipos' or token == 'tk_modulo' or token == 'desde' or token == 'const' or token == 'mientras' or token == 'tk_corchete_derecho' or token == 'hasta' or token == 'tk_mayor' or token == 'tk_coma' or token == 'var' or token == 'sino' or token == 'tk_mayor_igual' or token == 'tk_resta' or token == 'paso' or token == 'tk_menor' or token == 'repetir' or token == 'tk_parentesis_derecho' or token == 'tk_llave_derecha' or token == 'caso' or token == 'inicio' or token == 'tk_llave_izquierda' or token == 'tk_asignacion' or token == 'tk_punto_y_coma' or token == 'fin' or token == 'and' or token == 'or' or token == 'tk_menor_igual' or token == 'eval' or token == 'si' or token == 'tk_igual_que' or token == 'tk_distinto_de'):
		pass
	else:
		syntaxError(set({'id', 'tk_potenciacion', 'tk_suma', 'retorna', 'tk_division', 'tk_multiplicacion', 'tipos', 'tk_igual_que', 'tk_corchete_izquierdo', 'tk_modulo', 'desde', 'tk_punto', 'const', 'mientras', 'tk_corchete_derecho', 'hasta', 'tk_mayor', 'tk_coma', 'var', 'sino', 'tk_mayor_igual', 'tk_resta', 'paso', 'tk_menor', 'repetir', 'tk_parentesis_derecho', 'caso', 'inicio', 'tk_llave_izquierda', 'tk_asignacion', 'tk_punto_y_coma', 'fin', 'and', 'or', 'tk_menor_igual', 'eval', 'si', 'tk_llave_derecha', 'tk_distinto_de'}))


def operador():
	if(token == 'tk_modulo'):
		emparejar('tk_modulo')
	elif(token == 'tk_multiplicacion'):
		emparejar('tk_multiplicacion')
	elif(token == 'tk_potenciacion'):
		emparejar('tk_potenciacion')
	elif(token == 'tk_resta'):
		emparejar('tk_resta')
	elif(token == 'tk_suma'):
		emparejar('tk_suma')
	elif(token == 'tk_division'):
		emparejar('tk_division')
	elif(token == 'tk_igual_que'):
		emparejar('tk_igual_que')
	elif(token == 'tk_menor'):
		emparejar('tk_menor')
	elif(token == 'tk_distinto_de'):
		emparejar('tk_distinto_de')
	elif(token == 'tk_menor_igual'):
		emparejar('tk_menor_igual')
	elif(token == 'tk_mayor'):
		emparejar('tk_mayor')
	elif(token == 'tk_mayor_igual'):
		emparejar('tk_mayor_igual')
	elif(token == 'and'):
		emparejar('and')
	elif(token == 'or'):
		emparejar('or')
	else:
		syntaxError(set({'tk_menor', 'tk_potenciacion', 'tk_suma', 'tk_division', 'tk_multiplicacion', 'and', 'or', 'tk_mayor', 'tk_modulo', 'tk_distinto_de', 'tk_menor_igual', 'tk_mayor_igual', 'tk_igual_que', 'tk_resta'}))


def asignacion():
	if(token == 'tk_asignacion'):
		emparejar('tk_asignacion')
		expresion()
	else:
		syntaxError(set({'tk_asignacion'}))


def condicional():
	if(token == 'si'):
		emparejar('si')
		emparejar('tk_parentesis_izquierdo')
		expresion()
		emparejar('tk_parentesis_derecho')
		emparejar('tk_llave_izquierda')
		sentencias_internas()
		mas_condicionales()
		emparejar('tk_llave_derecha')
	else:
		syntaxError(set({'si'}))


def mas_condicionales():
	if(token == 'sino'):
		emparejar('sino')
		condicional_()
	elif(token == 'tk_llave_derecha'):
		pass
	else:
		syntaxError(set({'tk_llave_derecha', 'sino'}))


def condicional_():
	if(token == 'si'):
		emparejar('si')
		emparejar('tk_parentesis_izquierdo')
		expresion()
		emparejar('tk_parentesis_derecho')
		sentencias_internas()
		mas_condicionales()
	elif(token == 'id' or token == 'repetir' or token == 'eval' or token == 'si' or token == 'tk_llave_derecha' or token == 'mientras' or token == 'desde'):
		sentencias_internas()
	elif(token == 'tk_llave_derecha'):
		pass
	else:
		syntaxError(set({'id', 'repetir', 'eval', 'si', 'tk_llave_derecha', 'mientras', 'desde'}))


def ciclo_mientras():
	if(token == 'mientras'):
		emparejar('mientras')
		emparejar('tk_parentesis_izquierdo')
		expresion()
		emparejar('tk_parentesis_derecho')
		emparejar('tk_llave_izquierda')
		sentencias_internas()
		emparejar('tk_llave_derecha')
	else:
		syntaxError(set({'mientras'}))


def sentencia_eval():
	if(token == 'eval'):
		emparejar('eval')
		emparejar('tk_llave_izquierda')
		emparejar('caso')
		emparejar('tk_parentesis_izquierdo')
		expresion()
		emparejar('tk_parentesis_derecho')
		sentencias_internas()
		mas_casos_eval()
		emparejar('tk_llave_derecha')
	else:
		syntaxError(set({'eval'}))


def mas_casos_eval():
	if(token == 'caso'):
		emparejar('caso')
		emparejar('tk_parentesis_izquierdo')
		expresion()
		emparejar('tk_parentesis_derecho')
		sentencias_internas()
		mas_casos_eval()
	elif(token == 'sino'):
		emparejar('sino')
		sentencias_internas()
	elif(token == 'tk_llave_derecha'):
		pass
	else:
		syntaxError(set({'tk_llave_derecha', 'sino', 'caso'}))


def ciclo_desde():
	if(token == 'desde'):
		emparejar('desde')
		emparejar('id')
		emparejar('tk_asignacion')
		expresion()
		emparejar('hasta')
		expresion()
		paso_opt()
		emparejar('tk_llave_izquierda')
		sentencias_internas()
		emparejar('tk_llave_derecha')
	else:
		syntaxError(set({'desde'}))


def paso_opt():
	if(token == 'paso'):
		emparejar('paso')
		expresion()
	elif(token == 'tk_llave_izquierda'):
		pass
	else:
		syntaxError(set({'tk_llave_izquierda', 'paso'}))


def llamada_subrutina():
	if(token == 'tk_parentesis_izquierdo'):
		emparejar('tk_parentesis_izquierdo')
		parametros()
		emparejar('tk_parentesis_derecho')
	else:
		syntaxError(set({'tk_parentesis_izquierdo'}))


def parametros():
	if(token == 'id' or token == 'TRUE' or token == 'tk_suma' or token == 'tk_cadena' or token == 'SI' or token == 'tk_parentesis_izquierdo' or token == 'not' or token == 'tk_resta' or token == 'tk_llave_izquierda' or token == 'NO' or token == 'tk_numero' or token == 'FALSE'):
		expresion()
		mas_parametros()
	elif(token == 'tk_parentesis_derecho'):
		pass
	else:
		syntaxError(set({'id', 'TRUE', 'tk_suma', 'tk_cadena', 'SI', 'tk_parentesis_izquierdo', 'tk_parentesis_derecho', 'not', 'tk_resta', 'tk_llave_izquierda', 'NO', 'tk_numero', 'FALSE'}))


def mas_parametros():
	if(token == 'tk_coma'):
		emparejar('tk_coma')
		expresion()
		mas_parametros()
	elif(token == 'tk_parentesis_derecho' or token == 'tk_corchete_derecho'):
		pass
	else:
		syntaxError(set({'tk_parentesis_derecho', 'tk_corchete_derecho', 'tk_coma'}))


def sentencia_retorna_subrutina():
	if(token == 'retorna'):
		emparejar('retorna')
		valor_retorno()
	elif(token == 'inicio' or token == 'var' or token == 'tipos' or token == 'const'):
		pass
	else:
		syntaxError(set({'inicio', 'retorna', 'var', 'const', 'tipos'}))


def sentencia_retorna_main():
	if(token == 'retorna'):
		emparejar('retorna')
		valor_retorno()
	elif(token == 'fin'):
		pass
	else:
		syntaxError(set({'retorna', 'fin'}))


def valor_retorno():
	if(token == 'tk_parentesis_izquierdo'):
		emparejar('tk_parentesis_izquierdo')
		expresion()
		emparejar('tk_parentesis_derecho')
	elif(token == 'id' or token == 'TRUE' or token == 'tk_suma' or token == 'tk_cadena' or token == 'SI' or token == 'tk_parentesis_izquierdo' or token == 'not' or token == 'tk_resta' or token == 'tk_llave_izquierda' or token == 'NO' or token == 'tk_numero' or token == 'FALSE'):
		expresion()
	elif(token == 'id' or token == 'registro' or token == 'cadena' or token == 'vector' or token == 'logico' or token == 'numerico' or token == 'matriz'):
		tipo_dato()
	else:
		syntaxError(set({'id', 'TRUE', 'tk_suma', 'vector', 'tk_resta', 'tk_llave_izquierda', 'SI', 'numerico', 'matriz', 'registro', 'cadena', 'tk_cadena', 'tk_parentesis_izquierdo', 'not', 'NO', 'logico', 'tk_numero', 'FALSE'}))


def ciclo_repetir():
	if(token == 'repetir'):
		emparejar('repetir')
		sentencias_internas()
		emparejar('hasta')
		emparejar('tk_parentesis_izquierdo')
		expresion()
		emparejar('tk_parentesis_derecho')
	else:
		syntaxError(set({'repetir'}))


def subrutina_():
	if(token == 'subrutina'):
		emparejar('subrutina')
		emparejar('id')
		emparejar('tk_parentesis_izquierdo')
		param_subrutina()
		emparejar('tk_parentesis_derecho')
		sentencia_retorna_subrutina()
		declaracion()
		main()
		subrutina_()
	elif(token == '$'):
		pass
	else:
		syntaxError(set({'$', 'subrutina'}))


def param_subrutina():
	if(token == 'id' or token == 'ref'):
		param_ref()
		emparejar('id')
		otros_id()
		emparejar('tk_dos_puntos')
		tipo_dato()
		mas_param_subrutina()
	elif(token == 'tk_parentesis_derecho'):
		pass
	else:
		syntaxError(set({'id', 'ref', 'tk_parentesis_derecho'}))


def mas_param_subrutina():
	if(token == 'tk_punto_y_coma' or token == 'tk_parentesis_derecho'):
		punto_y_coma_opcional_subrutina()
	else:
		syntaxError(set({'tk_punto_y_coma', 'tk_parentesis_derecho'}))


def punto_y_coma_opcional_subrutina():
	if(token == 'tk_punto_y_coma'):
		emparejar('tk_punto_y_coma')
		param_ref()
		emparejar('id')
		otros_id()
		emparejar('tk_dos_puntos')
		tipo_dato()
		mas_param_subrutina()
	elif(token == 'tk_parentesis_derecho'):
		pass
	else:
		syntaxError(set({'tk_punto_y_coma', 'tk_parentesis_derecho'}))


def param_ref():
	if(token == 'ref'):
		emparejar('ref')
	elif(token == 'id'):
		pass
	else:
		syntaxError(set({'id', 'ref'}))


init()
